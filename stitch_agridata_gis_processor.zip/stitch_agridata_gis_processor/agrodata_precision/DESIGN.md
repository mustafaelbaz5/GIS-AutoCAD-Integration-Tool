---
name: AgroData Precision
colors:
  surface: '#10131a'
  surface-dim: '#10131a'
  surface-bright: '#363941'
  surface-container-lowest: '#0b0e15'
  surface-container-low: '#191b23'
  surface-container: '#1d2027'
  surface-container-high: '#272a31'
  surface-container-highest: '#32353c'
  on-surface: '#e1e2ec'
  on-surface-variant: '#c2c6d6'
  inverse-surface: '#e1e2ec'
  inverse-on-surface: '#2e3038'
  outline: '#8c909f'
  outline-variant: '#424754'
  surface-tint: '#adc6ff'
  primary: '#adc6ff'
  on-primary: '#002e6a'
  primary-container: '#4d8eff'
  on-primary-container: '#00285d'
  inverse-primary: '#005ac2'
  secondary: '#b9c8de'
  on-secondary: '#233143'
  secondary-container: '#39485a'
  on-secondary-container: '#a7b6cc'
  tertiary: '#ffb786'
  on-tertiary: '#502400'
  tertiary-container: '#df7412'
  on-tertiary-container: '#461f00'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#d8e2ff'
  primary-fixed-dim: '#adc6ff'
  on-primary-fixed: '#001a42'
  on-primary-fixed-variant: '#004395'
  secondary-fixed: '#d4e4fa'
  secondary-fixed-dim: '#b9c8de'
  on-secondary-fixed: '#0d1c2d'
  on-secondary-fixed-variant: '#39485a'
  tertiary-fixed: '#ffdcc6'
  tertiary-fixed-dim: '#ffb786'
  on-tertiary-fixed: '#311400'
  on-tertiary-fixed-variant: '#723600'
  background: '#10131a'
  on-background: '#e1e2ec'
  surface-variant: '#32353c'
typography:
  headline-xl:
    fontFamily: beVietnamPro
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 48px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: beVietnamPro
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 36px
  headline-md:
    fontFamily: beVietnamPro
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 32px
  body-lg:
    fontFamily: beVietnamPro
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 32px
  body-md:
    fontFamily: beVietnamPro
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 28px
  body-sm:
    fontFamily: beVietnamPro
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 24px
  label-md:
    fontFamily: geist
    fontSize: 13px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.05em
  label-sm:
    fontFamily: geist
    fontSize: 11px
    fontWeight: '600'
    lineHeight: 14px
    letterSpacing: 0.08em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  xs: 4px
  sm: 8px
  md: 16px
  lg: 24px
  xl: 32px
  gutter: 20px
  margin: 40px
---

## Brand & Style
The design system is engineered for high-density agricultural data processing, prioritizing precision and visual calm. It adopts a **Modern Corporate** aesthetic influenced by the functional minimalism of developer-centric tools. The interface balances technical rigor with approachable clarity, ensuring that complex spatial and tabular data remain the focal point. 

The emotional response is one of reliability and "quiet power." By utilizing deep charcoal foundations and surgical primary accents, the UI recedes to let data breathe, using the wheat motif sparingly as a watermark or loading indicator to ground the technical nature of the tool in the physical reality of farming.

## Colors
The palette is rooted in a deep navy-charcoal spectrum to reduce eye strain during long analytical sessions. 
- **Core Surfaces:** The background uses `#0f172a`, while interactive or contained surfaces use `#1e293b`.
- **Accents:** A single "Confident Blue" (`#3b82f6`) is reserved for primary functional triggers and active states. 
- **Semantic Feedback:** Success, Warning, and Error colors are desaturated to maintain the professional atmosphere while ensuring critical information is never missed.
- **Hierarchical Borders:** All surfaces are defined by a 1px border (`#334155`) rather than heavy shadows to maintain a "flat yet layered" look.

## Typography
The system uses **beVietnamPro** as the primary typeface for its geometric clarity and open apertures, which translate exceptionally well to the rounded terminals of Arabic scripts like Cairo or Tajawal. 

**Key Principles:**
- **RTL Optimization:** Line heights are increased by roughly 20% compared to standard Latin presets to accommodate the verticality of Arabic script.
- **Technical Mono:** **Geist** is used for labels, coordinates, and data metrics to provide a precise, developer-tool feel.
- **Alignment:** All text is right-aligned by default. Numerical data in tables remains tabular-aligned for easier comparison.

## Layout & Spacing
The layout follows a **Right-to-Left (RTL)** flow. Navigation sidebars are anchored to the right, and the reading pattern follows a right-to-left, top-to-bottom scan.

- **Grid Model:** A 12-column fluid grid system with 20px gutters. 
- **Spacing Scale:** A strict 8px-based linear scale is used for all internal component margins. 
- **Reflow:** On desktop, the sidebar is persistent. On smaller viewports, it collapses into a slim icon bar or a drawer, prioritizing the map or data visualization area.

## Elevation & Depth
Depth is communicated through **Tonal Layering** and **Subtle Outlines** rather than traditional shadows.
- **Level 0 (Background):** `#0f172a` - The base canvas.
- **Level 1 (Cards/Sidebar):** `#1e293b` with a 1px solid border of `#334155`.
- **Level 2 (Popovers/Modals):** Lighter surface color with a "Floating" effect created by a soft 15% opacity black shadow (0px 10px 30px) and a subtle `#475569` border.
- **Backdrop Blur:** Use a 12px blur on modal overlays to maintain context while focusing on the foreground task.

## Shapes
The system utilizes a **Rounded** corner strategy. 
- Standard buttons and input fields use **8px (rounded-md)**.
- Large cards and drop-zones use **12px (rounded-lg)**.
- Status badges and toggle pills use **Full Radius (pill-shaped)**.
This softens the technical nature of the data, making the tool feel more modern and user-friendly.

## Components
- **Buttons:** Primary buttons are solid `#3b82f6` with white text. Secondary buttons are ghost-style with the `#334155` border.
- **Drop-Zones:** Large containers for file uploads feature a 2px dashed border in `#475569` and a centered "Wheat" icon watermark.
- **Stats Cards:** Metrics are displayed in `headline-xl` (Geist) with a small trend indicator (Success/Error colors) and a thin-stroke Lucide icon in the top-left (RTL-mirrored).
- **Toggle Switches:** Modern pill-shaped switches. The track uses `#334155` when off and `#3b82f6` when on.
- **Inputs:** Dark backgrounds (`#0f172a`) with a 1px border. On focus, the border transitions to the primary blue with a 2px outer glow.
- **Spatial Compass:** For land borders, use a circular UI element with a `#1e293b` background, utilizing monospaced labels for degrees and coordinates.
- **Lists:** Clean rows separated by 1px borders, with hover states using a subtle `#1e293b` highlight.